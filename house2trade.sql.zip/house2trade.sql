-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2013 at 07:41 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `house2trade`
--

-- --------------------------------------------------------

--
-- Table structure for table `brokers`
--

CREATE TABLE IF NOT EXISTS `brokers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(80) NOT NULL,
  `lname` varchar(80) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `cell` varchar(45) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` tinytext NOT NULL,
  `cphone` varchar(100) NOT NULL,
  `cmail` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `license` int(10) unsigned NOT NULL,
  `subcribe` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `brokers`
--


-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `main` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `photo` tinytext NOT NULL,
  `property_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `broker_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `images`
--


-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE IF NOT EXISTS `owners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `broker_id` int(10) unsigned NOT NULL,
  `fname` varchar(80) NOT NULL,
  `lname` varchar(80) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `cell` tinytext NOT NULL,
  `seller` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `owners`
--


-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `url` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `content`, `url`) VALUES
(1, 'Home page', '<div class="grid_6">\n<div class="iframe-wrapper"><iframe allowfullscreen="" frameborder="0" height="255" mozallowfullscreen="" src="http://player.vimeo.com/video/17882714?portrait=0" webkitallowfullscreen="" width="440"></iframe></div>\n</div>\n\n<div class="grid_6">\n<h2>For brokers <span>To have more buyers and sell more properties</span></h2>\n\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p>\n<a class="btn-submit" href="http://dev.realitygroup.ru/house2trade/signup">Quick Registration</a></div>\n\n<div class="clear">&nbsp;</div>\n\n<div class="block-separator">&nbsp;</div>\n\n<div class="grid_6">\n<h2>For homeowners <span>To find the best offers using the most advanced tools</span></h2>\n\n<p>Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsamsit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt: um, totam rem aperiam, eaque ipsa quae.</p>\n<a class="btn-submit" href="#">Invite your broker</a> <span class="decision">or</span> <a class="link-more" href="http://dev.realitygroup.ru/house2trade/contacts">Contact us for details</a></div>\n\n<div class="grid_6">\n<div class="iframe-wrapper"><iframe allowfullscreen="" frameborder="0" height="255" mozallowfullscreen="" src="http://player.vimeo.com/video/17882714?portrait=0" webkitallowfullscreen="" width="440"></iframe></div>\n</div>\n\n<div class="clear">&nbsp;</div>\n\n<div class="block-separator">&nbsp;</div>\n\n<div class="grid_12 clearfix">\n<h2>Easy and effective way to sell</h2>\n\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p>\n\n<div class="iframe-wrapper"><iframe allowfullscreen="" frameborder="0" height="518" mozallowfullscreen="" src="http://player.vimeo.com/video/17882714?portrait=0" webkitallowfullscreen="" width="920"></iframe></div>\n</div>\n\n<div class="clear">&nbsp;</div>\n\n<div class="block-separator">&nbsp;</div>\n\n<div class="grid_12 clearfix">\n<h2>Join today and increase your sales</h2>\n</div>\n\n<div class="grid_6">\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p>\n\n<p>Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsamsit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt: um, totam rem aperiam, eaque ipsa quae.</p>\n\n<p><a class="link-more" href="http://dev.realitygroup.ru/house2trade/how-it-works">Learn how it works &raquo;</a></p>\n</div>\n\n<div class="grid_6">\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p>\n\n<p>Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsamsit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt: um, totam rem aperiam, eaque ipsa quae.</p>\n\n<p><a class="link-more" href="http://dev.realitygroup.ru/house2trade/virtual-tour">Watch virtual tour &raquo;</a></p>\n</div>\n', 'home'),
(2, 'Login page', '<h3 class="title">Questions?</h3>\r\n				<p class="steps_">\r\n					Feel free to contact us: <br/>\r\n					1-888-488-6481 <br />\r\n					<a class="link-more" href="<?=site_url('''');?>">info@house2trade.com</a>\r\n				</p>', 'login'),
(3, 'SignUp Page', '<h3 class="title">Questions?</h3>\r\n				<p class="steps_">\r\n					Feel free to contact us: <br/>\r\n					1-888-488-6481 <br />\r\n					<a class="link-more" href="<?=site_url('''');?>">info@house2trade.com</a>\r\n				</p>\r\n				<h3 class="title">Next Steps</h3>\r\n				<p class="steps_">\r\n					1. Add one or more properties to your profile. The email with invitation and registration information will be sent to homeowner.\r\n				</p>\r\n				<p class="steps_">\r\n					2. Add properties to favorites and potential buy lists.\r\n				</p>\r\n				<p class="steps_">\r\n					3. The best match will be founded to make your life easier.\r\n				</p>', 'signup'),
(4, 'Search For One', NULL, 'search-for-one'),
(5, 'Step by step', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'step-by-step'),
(6, 'Trading concepts', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'trading-concepts'),
(7, 'How It Works?', '<div class="grid_10">\r\n	    			<h2>Do you want to have more buyers and <br/>earn more money? </h2>\r\n	    			<p>\r\n	    				Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta \r\n	    				sunt explicabo. Nemo enim ipsamsit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores \r\n	    				eos qui ratione voluptatem sequi nesciunt: um, totam rem aperiam, eaque ipsa quae.\r\n	    			</p>\r\n	    			<a href="#" class="btn-submit">Start learning </a> <span class="decision">or</span> 	\r\n	    			<a href="#" class="link-more" hidefocus="true">View step by step tutorial</a>    			\r\n	    		</div>\r\n	    		<div class="clear"> </div>\r\n	    		\r\n	    		<div class="block-separator"> </div>\r\n	    		\r\n	    		<div class="grid_10">\r\n	    			<h2>The tools for real estate brokers <span>Patented engine will find the best scenario in seconds</span></h2>\r\n	    			<p>\r\n	    				<img class="framed" src="img/h2t-howto.png" alt="" title="" />\r\n	    			</p>\r\n	    		</div>\r\n	    		<div class="clear"> </div>\r\n	    		\r\n	    		<div class="grid_10">\r\n	    			<ul class="how-steps">\r\n	    				<li>1. List your clients property.</li>\r\n	    				<li>2. Select property from our listing and add to "Favorite". Show this property to client.</li>\r\n	    				<li>3. If he likes it &mdash; add this property to "potential buy".</li>\r\n	    				<li>4. We will calculate and create scenario for your client.</li>\r\n	    				<li>5. After you get this scenario you can start to prepare documents for closing.</li>\r\n	    			</ul>\r\n	    		</div>', 'how-it-works'),
(8, 'Contacts page', '<p>This document1 provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\r\n\r\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\r\n\r\n<h2>Summary</h2>\r\n\r\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\r\n\r\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\r\n\r\n<h2>The web has become the platform for creative expression</h2>\r\n\r\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\r\n\r\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\r\n\r\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\r\n', 'contacts'),
(9, 'Company', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'company'),
(10, 'Advanced search', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'advanced-search'),
(11, 'About Us', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\r\n\r\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\r\n\r\n<h2>Summary</h2>\r\n\r\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\r\n\r\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\r\n\r\n<h2>The web has become the platform for creative expression</h2>\r\n\r\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\r\n\r\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\r\n\r\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\r\n', 'about-us'),
(12, 'Virtual tour', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'virtual-tour'),
(13, 'Properties for sale', '<p>sdsdsadasdsadsafasc dfadsfs aadfsdf</p>\r\n', 'properties-for-sale'),
(14, 'Lastest offers', '<p>This document provides an overview of Adobe&#39;s involvement in the web, why the web and web standards are important to Adobe&#39;s strategy and what Adobe is doing to help move the web forward. The primary goal is to provide insight into Adobe&#39;s thinking and plans around the web platform and the tools and services to create the web.</p>\n\n<p><a class="link-more" href="#">Download a PDF version of this document </a> (PDF, 47 KB)</p>\n\n<h2>Summary</h2>\n\n<p>Adobe makes tools that enable designers and developers to share their creativity with the world. The advent of sophisticated graphical and interactive features has made it possible for the web to deliver highly engaging experiences. For Adobe, that means the need for new creative tools and services.</p>\n\n<p>Adobe believes that the web platform will deliver all the rich experiences that authors want and need. Adobe is helping make this vision a reality through its contributions of creative features such as advanced layout and cinematic effects to web standards and HTML rendering engines. In addition, Adobe is building the best tools and services in the world to enable web designers who code and developers who value design to create beautiful mobile-ready content and apps.</p>\n\n<h2>The web has become the platform for creative expression</h2>\n\n<p>Adobe has a long history in delivering technologies that allow creatives to express themselves and connect with millions of people.</p>\n\n<p>A web that has a strong foundation built to support creative features is vital to Adobe&#39;s efforts to serve its users, allowing them to use this medium to freely express themselves. A more expressive web creates new opportunities for Adobe to build great tools and services to create beautiful content.</p>\n\n<p>And Adobe&#39;s tools and services are increasingly built and delivered on the web platform itself, which makes the web platform features, design and robustness a key to Adobe&#39;s success.</p>\n', 'lastest-offers');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE IF NOT EXISTS `properties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `listing_id` int(10) unsigned NOT NULL,
  `broker_id` int(10) unsigned NOT NULL,
  `owner_id` int(10) unsigned NOT NULL,
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `address1` tinytext NOT NULL,
  `address2` tinytext NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(60) NOT NULL,
  `zip_code` int(10) unsigned NOT NULL,
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `bathrooms` tinyint(3) unsigned NOT NULL,
  `bedrooms` tinyint(3) unsigned NOT NULL,
  `sqf` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `description` text NOT NULL,
  `tax` int(10) unsigned NOT NULL,
  `mls` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `properties`
--


-- --------------------------------------------------------

--
-- Table structure for table `property_favorite`
--

CREATE TABLE IF NOT EXISTS `property_favorite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` int(10) unsigned NOT NULL,
  `property` int(10) unsigned NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `property_favorite`
--


-- --------------------------------------------------------

--
-- Table structure for table `property_potentialby`
--

CREATE TABLE IF NOT EXISTS `property_potentialby` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` int(10) unsigned NOT NULL,
  `property` int(10) unsigned NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `property_potentialby`
--


-- --------------------------------------------------------

--
-- Table structure for table `property_type`
--

CREATE TABLE IF NOT EXISTS `property_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `property_type`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signdate` datetime NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `temporary_code` varchar(25) DEFAULT NULL,
  `date_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `class`, `user_id`, `email`, `password`, `signdate`, `status`, `temporary_code`, `date_update`) VALUES
(1, 1, 0, 'admin@house2trade.com', 'e10adc3949ba59abbe56e057f20f883e', '0000-00-00 00:00:00', 1, '', '2013-03-22 12:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `users_class`
--

CREATE TABLE IF NOT EXISTS `users_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translit` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users_class`
--

INSERT INTO `users_class` (`id`, `translit`, `title`, `comment`) VALUES
(1, 'administrator', 'Администратор', ''),
(2, 'broker', 'Брокер', ''),
(3, 'homeowner', 'Владелец дома', '');
